const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const db = require("./db");

const app = express();

// Middleware
app.use(cors()); // Allows your React Native app to make requests to this API
app.use(express.json()); // Parses incoming JSON data

// ==========================================
// ENDPOINT 1: User Registration
// ==========================================
app.post("/api/register", async (req, res) => {
  try {
    const { fullName, email, password, role } = req.body;

    // Securely hash the password before saving it to the database
    const hashedPassword = await bcrypt.hash(password, 10);
    const userRole = role || "User";

    const [result] = await db.query("INSERT INTO USERS (fullName, email, password_hash, role) VALUES (?, ?, ?, ?)", [fullName, email, hashedPassword, userRole]);

    res.status(201).json({
      status: "success",
      message: "User registered successfully",
      userID: result.insertId,
    });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

// ==========================================
// ENDPOINT 2: User Login
// ==========================================
app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find the user by email
    const [users] = await db.query("SELECT * FROM USERS WHERE email = ?", [email]);

    if (users.length === 0) {
      return res.status(404).json({ status: "error", message: "User not found" });
    }

    const user = users[0];

    // Compare the provided password with the hashed password in the database
    const isValidPassword = await bcrypt.compare(password, user.password_hash);

    if (isValidPassword) {
      delete user.password_hash; // Remove the hash from the response for security
      res.status(200).json({ status: "success", message: "Login successful", user });
    } else {
      res.status(401).json({ status: "error", message: "Invalid password" });
    }
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

// ==========================================
// ENDPOINT 3: Fetch All Events
// ==========================================
app.get("/api/events", async (req, res) => {
  try {
    const [events] = await db.query("SELECT * FROM EVENTS ORDER BY eventDate ASC");
    res.status(200).json({ status: "success", data: events });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

// ==========================================
// START THE SERVER
// ==========================================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`TLF Backend API is running on http://localhost:${PORT}`);
});
