const db = require("./db");
db.query("CREATE DATABASE tlf_database")
  .then(() => {
    console.log("Database 'tlf_database' created successfully!");
    process.exit();
  })
  .catch((err) => {
    console.error("Error creating database:", err.message);
    process.exit();
  });
