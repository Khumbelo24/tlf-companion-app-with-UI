const db = require("./db");

async function setupDatabase() {
  try {
    await db.query(`CREATE TABLE IF NOT EXISTS USERS (
            userID INT AUTO_INCREMENT PRIMARY KEY,
            fullName VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) DEFAULT 'User',
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);
    console.log("USERS table created!");

    await db.query(`CREATE TABLE IF NOT EXISTS EVENTS (
            eventID INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            eventDate DATETIME NOT NULL,
            location VARCHAR(255) NOT NULL,
            createdBy INT
        )`);
    console.log("EVENTS table created!");

    process.exit();
  } catch (err) {
    console.error("Error creating tables:", err.message);
    process.exit();
  }
}

setupDatabase();
