const mysql = require("mysql2");

// Create a connection pool to handle multiple simultaneous requests
const pool = mysql.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: "tlf_database", // Updated to point to your new database
  port: 3307,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Test the connection
pool.getConnection((err, conn) => {
  if (err) {
    console.error("Database connection failed: ", err.message);
  } else {
    console.log("Connected to MySQL on port 3307 successfully!");
    conn.release();
  }
});

// Export the promise-based pool for use in other files
module.exports = pool.promise();
