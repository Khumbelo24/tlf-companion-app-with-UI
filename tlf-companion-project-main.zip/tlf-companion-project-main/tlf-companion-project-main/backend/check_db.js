const db = require("./db");

db.query("SHOW DATABASES")
  .then(([rows]) => {
    console.log(
      "Databases found:",
      rows.map((r) => Object.values(r)[0]),
    );
    process.exit();
  })
  .catch((err) => {
    console.error("Error fetching databases:", err.message);
    process.exit();
  });
