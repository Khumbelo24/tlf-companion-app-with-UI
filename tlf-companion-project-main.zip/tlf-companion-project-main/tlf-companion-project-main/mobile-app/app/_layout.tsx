import { Stack } from 'expo-router';
import React, { useState } from 'react';
import LoginScreen from '../LoginScreen'; 

export default function RootLayout() {
  // This line defines the missing variables and fixes the red squigglies!
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // If not logged in, render the login page directly
  if (!isLoggedIn) {
    // @ts-ignore
    return <LoginScreen onLoginSuccess={() => setIsLoggedIn(true)} />;
  }

  // Once logged in, show the main tab screens
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" />
    </Stack>
  );
}