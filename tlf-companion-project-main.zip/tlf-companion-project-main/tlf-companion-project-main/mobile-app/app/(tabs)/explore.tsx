import React from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';

const EVENTS = [
  { id: '1', title: 'Winter Blanket Drive', date: '15 June 2026', time: '09:00', loc: 'Pretoria Central' },
  { id: '2', title: 'Skills Development Workshop', date: '22 June 2026', time: '14:00', loc: 'TLF Main Hall' },
];

export default function ExploreScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.titleArea}>
        <Text style={styles.mainTitle}>Upcoming Events</Text>
      </View>
      <FlatList
        data={EVENTS}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 20 }}
        renderItem={({ item }) => (
          <View style={styles.eventCard}>
            <Text style={styles.eventTitle}>{item.title}</Text>
            <View style={styles.infoRow}>
              <Feather name="calendar" size={14} color="#64748B" />
              <Text style={styles.infoText}>{item.date} at {item.time}</Text>
            </View>
            <View style={styles.infoRow}>
              <Feather name="map-pin" size={14} color="#64748B" />
              <Text style={styles.infoText}>{item.loc}</Text>
            </View>
            <TouchableOpacity style={styles.btn}>
              <Text style={styles.btnText}>Register Interest</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  titleArea: { paddingTop: 50, paddingHorizontal: 20, paddingBottom: 10 },
  mainTitle: { fontSize: 24, fontWeight: 'bold', color: '#0A306E' },
  eventCard: { backgroundColor: '#FFF', padding: 16, borderRadius: 12, marginBottom: 16, borderWidth: 1, borderColor: '#E2E8F0' },
  eventTitle: { fontSize: 16, fontWeight: 'bold', color: '#1E293B', marginBottom: 8 },
  infoRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  infoText: { color: '#64748B', fontSize: 13, marginLeft: 6 },
  btn: { backgroundColor: '#0A306E', marginTop: 12, paddingVertical: 10, borderRadius: 8, alignItems: 'center' },
  btnText: { color: '#FFF', fontWeight: '600', fontSize: 14 }
});