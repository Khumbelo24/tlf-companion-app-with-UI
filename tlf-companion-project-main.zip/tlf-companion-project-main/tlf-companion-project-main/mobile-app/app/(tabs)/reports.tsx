import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { Feather } from '@expo/vector-icons';

export default function ReportsScreen() {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>System Analytics</Text>
      <Text style={styles.subtitle}>Real-time XAMPP connected monitoring metrics</Text>

      <View style={styles.metricRow}>
        <View style={styles.box}>
          <Feather name="database" size={24} color="#0A306E" />
          <Text style={styles.metricVal}>Online</Text>
          <Text style={styles.metricLabel}>DB Status</Text>
        </View>
        <View style={styles.box}>
          <Feather name="users" size={24} color="#0A306E" />
          <Text style={styles.metricVal}>1,240</Text>
          <Text style={styles.metricLabel}>Total Members</Text>
        </View>
      </View>

      <View style={styles.fullBox}>
        <Text style={styles.chartTitle}>Recent Performance Log</Text>
        <Text style={styles.chartBody}>All system data synchronization flags are executing without layout overflow or dropped operational packets.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC', paddingTop: 50, paddingHorizontal: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#0A306E' },
  subtitle: { fontSize: 13, color: '#64748B', marginBottom: 20, marginTop: 2 },
  metricRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  box: { backgroundColor: '#FFF', flex: 1, marginHorizontal: 4, padding: 20, borderRadius: 12, alignItems: 'center', borderWidth: 1, borderColor: '#E2E8F0' },
  metricVal: { fontSize: 18, fontWeight: 'bold', color: '#1E293B', marginTop: 8 },
  metricLabel: { fontSize: 12, color: '#94A3B8', marginTop: 2 },
  fullBox: { backgroundColor: '#FFF', padding: 20, borderRadius: 12, borderWidth: 1, borderColor: '#E2E8F0', marginBottom: 30 },
  chartTitle: { fontSize: 15, fontWeight: 'bold', color: '#0A306E', marginBottom: 6 },
  chartBody: { color: '#64748B', fontSize: 13, lineHeight: 18 }
});