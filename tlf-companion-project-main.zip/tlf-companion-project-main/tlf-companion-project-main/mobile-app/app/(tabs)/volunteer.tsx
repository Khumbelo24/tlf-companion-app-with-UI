import React from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity } from 'react-native';

export default function VolunteerScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Log Volunteer Hours</Text>
      <Text style={styles.sub}>Track project execution indicators live</Text>

      <View style={styles.form}>
        <Text style={styles.label}>Project Focus Area</Text>
        <TextInput style={styles.input} placeholder="e.g. Youth Development Support" placeholderTextColor="#94A3B8" />

        <Text style={styles.label}>Hours Contributed</Text>
        <TextInput style={styles.input} placeholder="e.g. 4" keyboardType="numeric" placeholderTextColor="#94A3B8" />

        <TouchableOpacity style={styles.submitBtn}>
          <Text style={styles.submitText}>Save Entry to Server</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC', paddingTop: 50, paddingHorizontal: 24 },
  heading: { fontSize: 24, fontWeight: 'bold', color: '#0A306E' },
  sub: { fontSize: 14, color: '#64748B', marginTop: 4, marginBottom: 24 },
  form: { backgroundColor: '#FFF', padding: 20, borderRadius: 12, borderWidth: 1, borderColor: '#E2E8F0' },
  label: { fontSize: 14, fontWeight: '600', color: '#334155', marginBottom: 6 },
  input: { borderWidth: 1, borderColor: '#CBD5E1', borderRadius: 8, padding: 12, fontSize: 15, marginBottom: 16, color: '#334155' },
  submitBtn: { backgroundColor: '#0A306E', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  submitText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 }
});