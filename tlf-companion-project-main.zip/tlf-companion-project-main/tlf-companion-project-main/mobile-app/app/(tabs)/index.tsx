import React from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.welcomeText}>Welcome Back</Text>
          <Text style={styles.subText}>Tshwane Leadership Foundation Hub</Text>
        </View>
        <TouchableOpacity style={styles.profileBadge}>
          <Feather name="user" size={20} color="#0A306E" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.statContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>12</Text>
          <Text style={styles.statLabel}>Active Events</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>45h</Text>
          <Text style={styles.statLabel}>Served</Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Latest Updates</Text>
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Feather name="award" size={20} color="#0A306E" style={{ marginRight: 8 }} />
          <Text style={styles.cardTitle}>Community Outreach Success</Text>
        </View>
        <Text style={styles.cardBody}>The central Pretoria food security and shelter project successfully onboarded new support groups this week.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { backgroundColor: '#0A306E', paddingHorizontal: 24, paddingTop: 50, paddingBottom: 30, borderBottomLeftRadius: 24, borderBottomRightRadius: 24, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  welcomeText: { fontSize: 24, fontWeight: 'bold', color: '#FFF' },
  subText: { fontSize: 13, color: '#CBD5E1', marginTop: 4 },
  profileBadge: { backgroundColor: '#FFF', padding: 10, borderRadius: 50 },
  statContainer: { flexDirection: 'row', paddingHorizontal: 24, marginTop: -20, justifyContent: 'space-between' },
  statCard: { backgroundColor: '#FFF', flex: 1, marginHorizontal: 6, padding: 16, borderRadius: 12, alignItems: 'center', elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  statNumber: { fontSize: 22, fontWeight: 'bold', color: '#0A306E' },
  statLabel: { fontSize: 12, color: '#64748B', marginTop: 2 },
  sectionTitle: { fontSize: 18, fontWeight: '700', color: '#1E293B', paddingHorizontal: 24, marginTop: 24, marginBottom: 12 },
  card: { backgroundColor: '#FFF', padding: 20, marginHorizontal: 24, borderRadius: 12, borderWidth: 1, borderColor: '#E2E8F0', marginBottom: 20 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', color: '#1E293B' },
  cardBody: { color: '#64748B', lineHeight: 20, fontSize: 14 }
});