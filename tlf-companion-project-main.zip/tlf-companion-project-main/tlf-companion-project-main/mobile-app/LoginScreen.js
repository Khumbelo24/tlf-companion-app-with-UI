import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, Dimensions } from 'react-native';
import { Feather } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

// We added { onLoginSuccess } here so the master layout can hear the button click
export default function LoginScreen({ onLoginSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [secureText, setSecureText] = useState(true);

  return (
    <View style={styles.container}>
      {/* Top Decorative Blue Wave Accent */}
      <View style={styles.topWave}>
        <View style={styles.waveCurve} />
      </View>

      {/* Branding Section */}
      <View style={styles.brandContainer}>
        <Text style={styles.brandTitle}>TLF</Text>
        <Text style={styles.brandSubtitle}>COMPANION APP</Text>
        <Text style={styles.brandTagline}>Empowering Communities</Text>
      </View>

      {/* Main Form Fields */}
      <View style={styles.formContainer}>
        <Text style={styles.welcomeText}>Welcome back!</Text>
        <Text style={styles.subtext}>Sign in to continue</Text>

        {/* Email Input Field */}
        <View style={styles.inputWrapper}>
          <Feather name="mail" size={20} color="#888" style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            placeholder="Email Address"
            placeholderTextColor="#AAA"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        {/* Password Input Field */}
        <View style={styles.inputWrapper}>
          <Feather name="lock" size={20} color="#888" style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#AAA"
            value={password}
            onChangeText={setPassword}
            secureTextEntry={secureText}
          />
          <TouchableOpacity onPress={() => setSecureText(!secureText)} style={styles.eyeIcon}>
            <Feather name={secureText ? "eye-off" : "eye"} size={20} color="#888" />
          </TouchableOpacity>
        </View>

        {/* Forgot Password Link */}
        <TouchableOpacity style={styles.forgotPasswordContainer}>
          <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
        </TouchableOpacity>

        {/* Login Button - Connected to onLoginSuccess */}
        <TouchableOpacity style={styles.loginButton} onPress={onLoginSuccess}>
          <Text style={styles.loginButtonText}>Login</Text>
        </TouchableOpacity>

        {/* Decorative Divider */}
        <View style={styles.dividerContainer}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>or</Text>
          <View style={styles.dividerLine} />
        </View>

        {/* Sign Up Button */}
        <TouchableOpacity style={styles.signUpButton}>
          <Text style={styles.signUpButtonText}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  topWave: {
    position: 'absolute',
    top: 0,
    width: width,
    height: 180,
    backgroundColor: '#0A306E',
    borderBottomLeftRadius: width * 0.2,
    borderBottomRightRadius: width * 0.2,
  },
  brandContainer: {
    alignItems: 'center',
    marginTop: 60,
    marginBottom: 30,
    zIndex: 10,
  },
  brandTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0A306E',
    letterSpacing: 2,
  },
  brandSubtitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#0A306E',
    marginTop: -5,
  },
  brandTagline: {
    fontSize: 11,
    color: '#555',
    marginTop: 5,
    fontStyle: 'italic',
  },
  formContainer: {
    width: '90%',
    paddingHorizontal: 10,
  },
  welcomeText: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#111',
    marginBottom: 4,
  },
  subtext: {
    fontSize: 14,
    color: '#666',
    marginBottom: 24,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAFAFA',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 10,
    paddingHorizontal: 14,
    height: 54,
    marginBottom: 16,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    color: '#333',
    fontSize: 16,
    height: '100%',
  },
  eyeIcon: {
    padding: 4,
  },
  forgotPasswordContainer: {
    alignSelf: 'flex-end',
    marginBottom: 24,
  },
  forgotPasswordText: {
    color: '#0A306E',
    fontWeight: '600',
    fontSize: 14,
  },
  loginButton: {
    backgroundColor: '#0A306E',
    height: 54,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#0A306E',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 3,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E2E8F0',
  },
  dividerText: {
    marginHorizontal: 10,
    color: '#AAA',
    fontSize: 14,
  },
  signUpButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: '#0A306E',
    height: 54,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  signUpButtonText: {
    color: '#0A306E',
    fontSize: 16,
    fontWeight: 'bold',
  },
});