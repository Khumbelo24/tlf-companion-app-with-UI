import axios from "axios";

// Use your computer's local IP address (found in your Metro bundler terminal)
const API_URL = "http://192.168.0.169:3000/api";

const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

export const registerUser = (userData) => api.post("/register", userData);
export const loginUser = (userData) => api.post("/login", userData);
export const fetchEvents = () => api.get("/events");

export default api;
